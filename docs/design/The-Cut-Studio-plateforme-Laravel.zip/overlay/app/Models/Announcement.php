<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Announcement extends Model
{
    protected $fillable = ['title', 'body', 'is_active'];
    protected $casts = ['is_active' => 'boolean'];
}
