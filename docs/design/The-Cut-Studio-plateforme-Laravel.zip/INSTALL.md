# Installation de la plateforme The Cut Studio (Laravel + Laragon)

Ce dossier contient le code de la plateforme (`overlay/`). Il s'ajoute à un projet Laravel neuf.
Prérequis : Laragon (PHP 8.2 ou plus, MySQL, Composer, Git). Vérifiez avec `php -v`.

## 1. Créer le projet Laravel dans le dépôt

Dans le terminal de Laragon :

```
cd C:\laragon\www\The-Cut-Studio
git rm src/.gitkeep
composer create-project laravel/laravel src
```

## 2. Copier le code de la plateforme

Copiez le contenu du dossier `overlay` dans `src`, en acceptant de remplacer les fichiers existants :

```
xcopy /E /Y /I C:\chemin\vers\overlay\* C:\laragon\www\The-Cut-Studio\src\
```

(ou glissez-déposez le contenu de `overlay` dans `src` et cliquez sur « Remplacer »).

Fichiers remplacés : `routes/web.php`, `app/Models/User.php`, `app/Providers/AppServiceProvider.php`,
`database/seeders/DatabaseSeeder.php` et la migration `0001_01_01_000000_create_users_table.php`.

## 3. Configurer la base de données

1. Dans Laragon, cliquez sur **Base de données** (HeidiSQL) et créez une base `the_cut_studio` (utf8mb4).
2. Dans `src/.env`, réglez :

```
APP_NAME="The Cut Studio"
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=the_cut_studio
DB_USERNAME=root
DB_PASSWORD=
```

## 4. Créer les tables et charger les données

```
cd src
php artisan migrate:fresh --seed
php artisan serve
```

Ouvrez http://127.0.0.1:8000 (ou http://the-cut-studio.test avec les hôtes virtuels de Laragon, en pointant vers `src/public`).

## 5. Comptes de démonstration

| Rôle | Téléphone | Mot de passe |
|---|---|---|
| Administrateur | 0990000000 | Admin@2026 |
| Client | 0970000000 | client123 |

**Changez ces mots de passe** avant toute mise en ligne.

## 6. Envoi sur GitHub

```
cd C:\laragon\www\The-Cut-Studio
git checkout -b dev/plateforme-laravel
git add .
git commit -m "Ajout de la plateforme Laravel"
git push origin dev/plateforme-laravel
```

Puis ouvrez une Pull Request que le Master valide.

## En cas de problème

- Écran blanc ou erreur 500 : `php artisan config:clear` puis `php artisan view:clear`.
- Erreur de connexion à la base : vérifiez que MySQL est démarré dans Laragon et que les lignes `DB_*` ne sont pas précédées de `#`.
- Les prix en FC ne changent pas : modifiez le taux dans Admin > Paramètres.
