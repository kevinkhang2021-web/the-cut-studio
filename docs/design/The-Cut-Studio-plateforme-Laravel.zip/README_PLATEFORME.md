# Plateforme The Cut Studio – fonctionnalités

## Côté client
- Inscription / connexion (téléphone ou email), profil, historique
- Catalogue : 4 consoles PS5 et 30 jeux PS4 du catalogue, recherche, filtre par gamme de prix, tri
- Panier, commande (retrait en salle ou livraison), stock décompté
- Réservation de sessions : grille des créneaux libres par poste et par heure, anti-conflits d'horaires, annulation
- Paiement mobile (M-Pesa, Airtel Money, Orange Money) simulé, reçu imprimable
- Tournois en ligne : liste, inscription avec pseudo, paiement des frais, classement
- Avis publics et réclamations privées, avec réponse du gérant

## Côté gérant (/admin)
- Tableau de bord : clients du jour, chiffre d'affaires, dépenses, bénéfice (jour et mois), taux d'utilisation, pannes, graphique 7 jours
- Réservations : confirmer, refuser, terminer, encaisser en espèces
- Commandes : préparer, livrer, annuler (remise en stock), encaisser en espèces
- Catalogue : ajout, modification, suppression, images
- Tournois : création, joueurs, résultats et classement
- Postes de jeu et pannes (un poste en panne n'est plus réservable)
- Dépenses par mois (calcul du bénéfice)
- Fiche client (réservations, commandes, paiements, tournois)
- Annonces avec partage WhatsApp
- Paramètres : taux USD/FC, tarif horaire, horaires, coordonnées

## Hypothèses à valider
- Tarif d'une session : 2 000 FC/heure (exemple du rapport), ouverture 9h-21h
- 3 postes PS5 et 3 postes PS4 (à adapter dans Admin > Postes)
- Prix saisis en dollars comme sur les étiquettes du catalogue ; FC = $ x taux (2 300)
- Paiement mobile simulé : voir `app/Services/PaymentService.php` pour brancher un vrai prestataire
